from setuptools import setup, find_packages

setup(
    name='ElectroMagneticField',
    version='0.1',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    author='Doron Shpigel',
    author_email='doron.shpigel@gmail.com',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    license='MIT',

)

