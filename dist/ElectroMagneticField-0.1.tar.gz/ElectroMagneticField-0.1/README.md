# ElectroMagneticField
 ElectroMagnetic Field package to work with vector based fields
